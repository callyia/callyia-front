// Cart.tsx
import React from 'react'

const Cart: React.FC = () => {
  return (
    <div>
      {/* 장바구니 내용 및 스타일을 추가하세요 */}
      <h2>장바구니</h2>
      {/* ... */}
    </div>
  )
}

export default Cart

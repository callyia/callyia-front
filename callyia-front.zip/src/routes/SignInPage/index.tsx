import SignIn from './SignInPage';

export default function ListPage() {
    return (
        <div>
            <SignIn/>
        </div>
        )
}
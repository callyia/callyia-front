import Planning from "./Planning";
import Board from "../../pages/Board";

export default function PlanningPage() {
  return (
    <section className="mt-4">
      <Planning />
      {/* <Board /> */}
    </section>
  );
}

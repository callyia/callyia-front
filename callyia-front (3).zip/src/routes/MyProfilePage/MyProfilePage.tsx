import React from 'react';
import './ProfilePage.css';

const MyProfile = () => {
  return (
    <div className="profile-container">
      <div className="profile-header">
        <div className="profile-left-section" style={{border: "2px solid black"}}>
          <p className="profile-self-introduction">자기 소개글1</p>
        </div>
        <div className="profile-right-section" style={{border: "2px solid black"}}>
          <div className="profile-stats">
            <div className="profile-post-count">게시글 수: 인자로 받기 1</div>
            <div className="profile-likes-count">좋아요 수 : 인자로 받기 2</div>
          </div>
        </div>
        <div>ddd</div>
      </div>
      {/* 이미지 디브 별로 3, 4씩 해서 스크롤 되게 */}
      <div className="profile-user-posts">
        {/* <h2>내 글</h2> */}
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
        <div className='test-test-test'>
          <img src="./profile/profile_like_icon.png" alt="post i liked" />
        </div>
      </div>
    </div>
  );
};

export default MyProfile;

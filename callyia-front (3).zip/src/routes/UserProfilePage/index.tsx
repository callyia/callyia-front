import UserProfile from './UserProfilePage';

export default function UserProfilePage() {
    return (
        <div>
            <UserProfile/>
        </div>
        )
}

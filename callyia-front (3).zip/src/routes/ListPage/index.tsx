import List from './ListPage';

export default function ListPage() {
    return (
        <div>
            <List/>
        </div>
        )
}
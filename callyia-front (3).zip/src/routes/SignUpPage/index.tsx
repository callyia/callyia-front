import SignUp from './SignUpPage';

export default function ListPage() {
    return (
        <div>
            <SignUp/>
        </div>
        )
}
module.exports = {
  bracketSpacing: false,
  jsxBracketSameLine: true,
  singleQuote: true,
  trailingComma: "none",
  arrowParens: "avoid",
  semi: false,
  printWidth: 90,
};
